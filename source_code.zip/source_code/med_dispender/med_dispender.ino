#include <WiFi.h>
#include <WebServer.h>
#include <uri/UriBraces.h>
#include <Preferences.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <time.h>

const char* WIFI_SSID = "SOUBAM";
const char* WIFI_PASS = "Linlin@1";

#define DEFAULT_PORT 5500
#define DEFAULT_TZ_MIN 330

#define BUZZER_PIN 25
#define LED_PIN 26
#define IR_PIN 27
#define IR_ACTIVE_LOW true

#define MAX_ALARMS 16
#define NAME_LEN 52
#define LATE_WINDOW_SEC 300

const char INDEX_HTML[] PROGMEM = R"rawliteral(<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Smart Medicine Alarm Scheduler</title>

<style>
    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        padding: 20px;
        font-family: Arial, sans-serif;
        background: #0f172a;
        color: #f8fafc;
    }

    .container {
        max-width: 500px;
        margin: 30px auto;
    }

    h1 {
        text-align: center;
        color: #38bdf8;
        margin-bottom: 8px;
    }

    .subtitle {
        text-align: center;
        color: #94a3b8;
        margin-bottom: 30px;
    }

    .card {
        background: #1e293b;
        padding: 24px;
        border-radius: 14px;
        margin-bottom: 20px;
    }

    h2 {
        font-size: 19px;
        margin-top: 0;
        margin-bottom: 20px;
    }

    label {
        display: block;
        margin-bottom: 8px;
        font-size: 14px;
        color: #cbd5e1;
    }

    input, select {
        width: 100%;
        padding: 12px;
        border: 1px solid #475569;
        border-radius: 8px;
        background: #334155;
        color: white;
        font-size: 16px;
        margin-bottom: 18px;
        color-scheme: dark;
    }

    .time-row {
        display: flex;
        gap: 10px;
    }

    .time-row > div {
        flex: 1;
        min-width: 0;
    }

    button {
        padding: 12px 16px;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer;
    }

    .save-btn {
        width: 100%;
        background: #38bdf8;
        color: #0f172a;
    }

    .alarm {
        background: #334155;
        padding: 15px;
        border-radius: 10px;
        margin-top: 12px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
    }

    .alarm-info {
        min-width: 0;
        overflow-wrap: anywhere;
    }

    .alarm-name {
        font-size: 16px;
        font-weight: bold;
    }

    .alarm-time {
        color: #38bdf8;
        font-size: 20px;
        margin-top: 6px;
    }

    .alarm-date {
        color: #94a3b8;
        font-size: 13px;
        margin-top: 5px;
    }

    .actions {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .toggle {
        width: 20px;
        height: 20px;
        margin: 0;
        cursor: pointer;
    }

    .delete-btn {
        background: #ef4444;
        color: white;
        padding: 10px;
    }

    .empty {
        color: #94a3b8;
        text-align: center;
        font-size: 14px;
    }

    .status {
        text-align: center;
        color: #94a3b8;
        font-size: 14px;
        margin-top: 15px;
    }

    .connection {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        margin-bottom: 20px;
        color: #94a3b8;
        font-size: 13px;
    }

    .dot {
        width: 9px;
        height: 9px;
        background: #64748b;
        border-radius: 50%;
    }
</style>
</head>

<body>

<div class="container">

    <h1>💊 Medicine Scheduler</h1>
    <p class="subtitle">ESP32 Smart Medicine Reminder</p>

    <div class="connection">
        <span class="dot" id="connectionDot"></span>
        <span id="connectionStatus">Checking ESP32...</span>
    </div>

    <div class="card">
        <h2>Set New Alarm</h2>

        <label for="alarmName">Alarm Name</label>
        <input
            type="text"
            id="alarmName"
            placeholder="e.g. Morning Medicine"
            maxlength="50"
        >

        <label for="alarmDate">Select Date</label>
        <input type="date" id="alarmDate">

        <label>Select Time</label>

        <div class="time-row">
            <div>
                <label for="hour">Hour</label>
                <select id="hour"></select>
            </div>

            <div>
                <label for="minute">Minute</label>
                <select id="minute"></select>
            </div>

            <div>
                <label for="ampm">AM / PM</label>
                <select id="ampm">
                    <option value="AM">AM</option>
                    <option value="PM">PM</option>
                </select>
            </div>
        </div>

        <button class="save-btn" onclick="addAlarm()">
            + Save Alarm
        </button>
    </div>

    <div class="card">
        <h2>Scheduled Alarms</h2>
        <div id="alarmList"></div>
    </div>

    <p class="status" id="status">Ready</p>

</div>

<script>
    const ESP32_URL = "";

    let alarms = [];

    const hourSelect = document.getElementById("hour");
    const minuteSelect = document.getElementById("minute");

    for (let i = 1; i <= 12; i++) {
        const option = document.createElement("option");
        option.value = i;
        option.textContent = String(i).padStart(2, "0");
        hourSelect.appendChild(option);
    }

    for (let i = 0; i < 60; i++) {
        const option = document.createElement("option");
        option.value = i;
        option.textContent = String(i).padStart(2, "0");
        minuteSelect.appendChild(option);
    }

    const now = new Date();

    function localDateString(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");

        return `${year}-${month}-${day}`;
    }

    document.getElementById("alarmDate").value =
        localDateString(now);

    hourSelect.value = now.getHours() % 12 || 12;
    minuteSelect.value = now.getMinutes();
    document.getElementById("ampm").value =
        now.getHours() >= 12 ? "PM" : "AM";

    function setStatus(message) {
        document.getElementById("status").textContent = message;
    }

    async function loadAlarms() {
        try {
            const response = await fetch(
                ESP32_URL + "/api/alarms",
                { cache: "no-store" }
            );

            if (!response.ok) {
                throw new Error("Failed to load alarms");
            }

            const data = await response.json();

            if (!Array.isArray(data)) {
                throw new Error("Invalid alarm data");
            }

            alarms = data;
            displayAlarms();

        } catch (error) {
            console.error(error);
            setStatus("Unable to load alarms from ESP32");
        }
    }

    async function addAlarm() {
        const name =
            document.getElementById("alarmName").value.trim()
            || "Medicine Alarm";

        const date =
            document.getElementById("alarmDate").value;

        const hour =
            parseInt(hourSelect.value, 10);

        const minute =
            parseInt(minuteSelect.value, 10);

        const ampm =
            document.getElementById("ampm").value;

        if (!date) {
            alert("Please select a date.");
            return;
        }

        let hour24 = hour % 12;

        if (ampm === "PM") {
            hour24 += 12;
        }

        const time =
            String(hour24).padStart(2, "0") + ":" +
            String(minute).padStart(2, "0");

        const alarm = {
            name: name,
            date: date,
            time: time,
            enabled: true
        };

        try {
            setStatus("Saving alarm...");

            const response = await fetch(
                ESP32_URL + "/api/alarms",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(alarm)
                }
            );

            if (!response.ok) {
                throw new Error("ESP32 rejected the alarm");
            }

            setStatus("Alarm saved successfully!");

            document.getElementById("alarmName").value = "";

            await loadAlarms();

        } catch (error) {
            console.error(error);
            setStatus("Failed to save alarm");
        }
    }

    async function deleteAlarm(id) {
        if (!confirm("Delete this alarm?")) {
            return;
        }

        try {
            const response = await fetch(
                ESP32_URL + "/api/alarms/" +
                encodeURIComponent(id),
                {
                    method: "DELETE"
                }
            );

            if (!response.ok) {
                throw new Error("Failed to delete alarm");
            }

            await loadAlarms();
            setStatus("Alarm deleted");

        } catch (error) {
            console.error(error);
            setStatus("Failed to delete alarm");
        }
    }

    async function toggleAlarm(id, enabled) {
        try {
            const response = await fetch(
                ESP32_URL + "/api/alarms/" +
                encodeURIComponent(id),
                {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        enabled: enabled
                    })
                }
            );

            if (!response.ok) {
                throw new Error("Failed to update alarm");
            }

            await loadAlarms();
            setStatus("Alarm updated");

        } catch (error) {
            console.error(error);
            setStatus("Failed to update alarm");
            await loadAlarms();
        }
    }

    function displayAlarms() {
        const list = document.getElementById("alarmList");

        list.innerHTML = "";

        if (alarms.length === 0) {
            const empty = document.createElement("p");
            empty.className = "empty";
            empty.textContent = "No alarms scheduled";
            list.appendChild(empty);
            return;
        }

        const sortedAlarms = [...alarms].sort((a, b) => {
            return (
                (a.date + "T" + a.time).localeCompare(
                    b.date + "T" + b.time
                )
            );
        });

        sortedAlarms.forEach(alarm => {
            const [hour, minute] =
                alarm.time.split(":").map(Number);

            const ampm = hour >= 12 ? "PM" : "AM";
            const displayHour = hour % 12 || 12;

            const formattedTime =
                `${displayHour}:` +
                `${String(minute).padStart(2, "0")} ${ampm}`;

            const alarmDiv = document.createElement("div");
            alarmDiv.className = "alarm";

            const info = document.createElement("div");
            info.className = "alarm-info";

            const name = document.createElement("div");
            name.className = "alarm-name";
            name.textContent = alarm.name;

            const time = document.createElement("div");
            time.className = "alarm-time";
            time.textContent = formattedTime;

            const date = document.createElement("div");
            date.className = "alarm-date";
            date.textContent = alarm.date;

            info.appendChild(name);
            info.appendChild(time);
            info.appendChild(date);

            const actions = document.createElement("div");
            actions.className = "actions";

            const toggle = document.createElement("input");
            toggle.type = "checkbox";
            toggle.className = "toggle";
            toggle.checked = alarm.enabled;

            toggle.addEventListener("change", () => {
                toggleAlarm(alarm.id, toggle.checked);
            });

            const deleteBtn = document.createElement("button");
            deleteBtn.className = "delete-btn";
            deleteBtn.textContent = "Delete";

            deleteBtn.addEventListener("click", () => {
                deleteAlarm(alarm.id);
            });

            actions.appendChild(toggle);
            actions.appendChild(deleteBtn);

            alarmDiv.appendChild(info);
            alarmDiv.appendChild(actions);

            list.appendChild(alarmDiv);
        });
    }

    async function checkConnection() {
        const dot = document.getElementById("connectionDot");
        const status =
            document.getElementById("connectionStatus");

        try {
            const response = await fetch(
                ESP32_URL + "/api/status",
                { cache: "no-store" }
            );

            if (!response.ok) {
                throw new Error("ESP32 unavailable");
            }

            dot.style.background = "#22c55e";
            status.textContent = "ESP32 Connected";

        } catch (error) {
            dot.style.background = "#ef4444";
            status.textContent = "ESP32 Disconnected";
        }
    }

    loadAlarms();
    checkConnection();

    setInterval(checkConnection, 10000);

</script>

</body>
</html>)rawliteral";

Adafruit_SSD1306 display(128, 64, &Wire, -1);
Preferences prefs;
WebServer* server = nullptr;

struct Alarm {
  uint32_t id;
  char name[NAME_LEN];
  char day[11];
  char hhmm[6];
  bool enabled;
};

Alarm alarms[MAX_ALARMS];
int alarmCount = 0;
uint32_t nextId = 1;
int tzMin = DEFAULT_TZ_MIN;
int port = DEFAULT_PORT;

bool alarmActive = false;
char activeName[NAME_LEN] = "";
unsigned long alarmStart = 0;
unsigned long lastBeep = 0;
bool beepState = false;
unsigned long stopShownUntil = 0;
unsigned long lastDraw = 0;
unsigned long lastWifiTry = 0;

String two(int v) {
  return v < 10 ? "0" + String(v) : String(v);
}

bool getNow(struct tm& t) {
  if (!getLocalTime(&t, 0)) return false;
  return t.tm_year > 120;
}

String timeString(struct tm& t) {
  return two(t.tm_hour) + ":" + two(t.tm_min) + ":" + two(t.tm_sec);
}

String dateString(struct tm& t) {
  return String(t.tm_year + 1900) + "-" + two(t.tm_mon + 1) + "-" + two(t.tm_mday);
}

void setStr(char* dst, size_t cap, const String& s) {
  size_t n = s.length();
  if (n > cap - 1) {
    n = cap - 1;
    while (n > 0 && (((unsigned char)s[n]) & 0xC0) == 0x80) n--;
  }
  memcpy(dst, s.c_str(), n);
  dst[n] = 0;
}

bool allDigits(const String& s, int from, int to) {
  for (int i = from; i < to; i++) {
    if (s[i] < '0' || s[i] > '9') return false;
  }
  return true;
}

bool validDay(const String& d) {
  if (d.length() != 10 || d[4] != '-' || d[7] != '-') return false;
  if (!allDigits(d, 0, 4) || !allDigits(d, 5, 7) || !allDigits(d, 8, 10)) return false;
  int y = d.substring(0, 4).toInt();
  int m = d.substring(5, 7).toInt();
  int dd = d.substring(8, 10).toInt();
  return y >= 2000 && y <= 2099 && m >= 1 && m <= 12 && dd >= 1 && dd <= 31;
}

bool validHm(const String& s) {
  if (s.length() != 5 || s[2] != ':') return false;
  if (!allDigits(s, 0, 2) || !allDigits(s, 3, 5)) return false;
  return s.substring(0, 2).toInt() < 24 && s.substring(3, 5).toInt() < 60;
}

time_t alarmEpoch(const Alarm& a) {
  int y, mo, d, h, mi;
  if (sscanf(a.day, "%d-%d-%d", &y, &mo, &d) != 3) return 0;
  if (sscanf(a.hhmm, "%d:%d", &h, &mi) != 2) return 0;
  struct tm t;
  memset(&t, 0, sizeof(t));
  t.tm_year = y - 1900;
  t.tm_mon = mo - 1;
  t.tm_mday = d;
  t.tm_hour = h;
  t.tm_min = mi;
  t.tm_isdst = -1;
  return mktime(&t);
}

String jsonEsc(const char* s) {
  String o;
  for (const char* p = s; *p; p++) {
    unsigned char c = (unsigned char)*p;
    if (c == '"') o += "\\\"";
    else if (c == '\\') o += "\\\\";
    else if (c < 0x20) o += ' ';
    else o += (char)c;
  }
  return o;
}

String jsonStr(const String& b, const char* key) {
  String k = String("\"") + key + "\"";
  int i = b.indexOf(k);
  if (i < 0) return "";
  i = b.indexOf(':', i + k.length());
  if (i < 0) return "";
  i++;
  while (i < (int)b.length() && (b[i] == ' ' || b[i] == '\n' || b[i] == '\r' || b[i] == '\t')) i++;
  if (i >= (int)b.length() || b[i] != '"') return "";
  i++;
  String out;
  while (i < (int)b.length() && b[i] != '"') {
    if (b[i] == '\\' && i + 1 < (int)b.length()) {
      i++;
      char c = b[i];
      if (c == 'n' || c == 't' || c == 'r') out += ' ';
      else out += c;
    } else {
      out += b[i];
    }
    i++;
  }
  return out;
}

int jsonTri(const String& b, const char* key) {
  String k = String("\"") + key + "\"";
  int i = b.indexOf(k);
  if (i < 0) return -1;
  i = b.indexOf(':', i + k.length());
  if (i < 0) return -1;
  i++;
  while (i < (int)b.length() && (b[i] == ' ' || b[i] == '\n' || b[i] == '\r' || b[i] == '\t')) i++;
  if (b.startsWith("true", i)) return 1;
  if (b.startsWith("false", i)) return 0;
  return -1;
}

String alarmJson(const Alarm& a) {
  String s = "{\"id\":\"" + String(a.id) + "\",\"name\":\"" + jsonEsc(a.name) + "\",";
  s += "\"date\":\"" + String(a.day) + "\",\"time\":\"" + String(a.hhmm) + "\",";
  s += String("\"enabled\":") + (a.enabled ? "true" : "false") + "}";
  return s;
}

int findAlarm(uint32_t id) {
  for (int i = 0; i < alarmCount; i++) {
    if (alarms[i].id == id) return i;
  }
  return -1;
}

void saveAlarms() {
  prefs.begin("medsched", false);
  prefs.putInt("cnt", alarmCount);
  prefs.putUInt("nid", nextId);
  if (alarmCount > 0) prefs.putBytes("alarms", alarms, sizeof(Alarm) * alarmCount);
  else prefs.remove("alarms");
  prefs.end();
}

void loadSettings() {
  prefs.begin("medsched", false);
  port = prefs.getInt("port", DEFAULT_PORT);
  tzMin = prefs.getInt("tz", DEFAULT_TZ_MIN);
  nextId = prefs.getUInt("nid", 1);
  int cnt = prefs.getInt("cnt", 0);
  if (cnt < 0 || cnt > MAX_ALARMS) cnt = 0;
  if (cnt > 0) {
    size_t want = sizeof(Alarm) * cnt;
    size_t got = prefs.getBytes("alarms", alarms, want);
    if (got != want) cnt = 0;
  }
  alarmCount = cnt;
  prefs.end();
}

void applyTimezone() {
  configTime((long)tzMin * 60, 0, "pool.ntp.org", "time.google.com");
}

void sendJson(int code, const String& body) {
  server->sendHeader("Access-Control-Allow-Origin", "*");
  server->sendHeader("Cache-Control", "no-store");
  server->send(code, "application/json", body);
}

void handleRoot() {
  server->send_P(200, "text/html", INDEX_HTML);
}

void handleGetAlarms() {
  String s = "[";
  for (int i = 0; i < alarmCount; i++) {
    if (i) s += ",";
    s += alarmJson(alarms[i]);
  }
  s += "]";
  sendJson(200, s);
}

void handlePostAlarm() {
  String body = server->arg("plain");
  String name = jsonStr(body, "name");
  name.trim();
  if (name.length() == 0) name = "Medicine Alarm";
  String day = jsonStr(body, "date");
  String hm = jsonStr(body, "time");
  if (!validDay(day) || !validHm(hm)) {
    sendJson(400, "{\"error\":\"invalid date or time\"}");
    return;
  }
  if (alarmCount >= MAX_ALARMS) {
    sendJson(409, "{\"error\":\"alarm list is full\"}");
    return;
  }
  int en = jsonTri(body, "enabled");
  Alarm& a = alarms[alarmCount];
  memset(&a, 0, sizeof(Alarm));
  a.id = nextId++;
  setStr(a.name, NAME_LEN, name);
  setStr(a.day, sizeof(a.day), day);
  setStr(a.hhmm, sizeof(a.hhmm), hm);
  a.enabled = en != 0;
  alarmCount++;
  saveAlarms();
  sendJson(201, alarmJson(a));
}

void handlePutAlarm() {
  int idx = findAlarm((uint32_t)server->pathArg(0).toInt());
  if (idx < 0) {
    sendJson(404, "{\"error\":\"not found\"}");
    return;
  }
  String body = server->arg("plain");
  int en = jsonTri(body, "enabled");
  if (en >= 0) alarms[idx].enabled = (en == 1);
  String n = jsonStr(body, "name");
  n.trim();
  if (n.length() > 0) setStr(alarms[idx].name, NAME_LEN, n);
  String d = jsonStr(body, "date");
  if (validDay(d)) setStr(alarms[idx].day, sizeof(alarms[idx].day), d);
  String hm = jsonStr(body, "time");
  if (validHm(hm)) setStr(alarms[idx].hhmm, sizeof(alarms[idx].hhmm), hm);
  saveAlarms();
  sendJson(200, alarmJson(alarms[idx]));
}

void handleDeleteAlarm() {
  int idx = findAlarm((uint32_t)server->pathArg(0).toInt());
  if (idx < 0) {
    sendJson(404, "{\"error\":\"not found\"}");
    return;
  }
  for (int i = idx; i < alarmCount - 1; i++) alarms[i] = alarms[i + 1];
  alarmCount--;
  saveAlarms();
  sendJson(200, "{\"ok\":true}");
}

void handleApiStatus() {
  struct tm t;
  String now = getNow(t) ? dateString(t) + " " + timeString(t) : "syncing";
  String s = "{\"online\":true,\"time\":\"" + now + "\",\"ip\":\"" + WiFi.localIP().toString() + "\",";
  s += "\"port\":" + String(port) + ",\"tzMinutes\":" + String(tzMin) + ",";
  s += String("\"ringing\":") + (alarmActive ? "true" : "false") + ",\"alarms\":" + String(alarmCount) + "}";
  sendJson(200, s);
}

void handleSetPort() {
  int p = server->arg("port").toInt();
  if (p < 1 || p > 65535) {
    server->send(400, "text/plain", "Use /setport?port=5500 with a value from 1 to 65535");
    return;
  }
  if (p == port) {
    server->send(200, "text/plain", "Port is already " + String(p));
    return;
  }
  prefs.begin("medsched", false);
  prefs.putInt("port", p);
  prefs.end();
  String url = "http://" + WiFi.localIP().toString() + ":" + String(p) + "/";
  server->send(200, "text/plain", "Port saved. Restarting. Open " + url + " in a few seconds.");
  delay(1500);
  ESP.restart();
}

void handleSetTz() {
  if (!server->hasArg("min")) {
    server->send(400, "text/plain", "Use /settz?min=330 (UTC offset in minutes)");
    return;
  }
  tzMin = constrain(server->arg("min").toInt(), -720, 840);
  prefs.begin("medsched", false);
  prefs.putInt("tz", tzMin);
  prefs.end();
  applyTimezone();
  server->send(200, "text/plain", "UTC offset set to " + String(tzMin) + " minutes");
}

void handleNotFound() {
  if (server->method() == HTTP_OPTIONS) {
    server->sendHeader("Access-Control-Allow-Origin", "*");
    server->sendHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
    server->sendHeader("Access-Control-Allow-Headers", "Content-Type");
    server->send(204);
    return;
  }
  server->send(404, "text/plain", "Not found");
}

bool motionDetected() {
  int v = digitalRead(IR_PIN);
  return IR_ACTIVE_LOW ? (v == LOW) : (v == HIGH);
}

void stopAlarm() {
  alarmActive = false;
  activeName[0] = 0;
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(LED_PIN, LOW);
  stopShownUntil = millis() + 5000;
}

void startAlarm(const char* name) {
  alarmActive = true;
  strncpy(activeName, name, NAME_LEN - 1);
  activeName[NAME_LEN - 1] = 0;
  alarmStart = millis();
  lastBeep = millis();
  beepState = true;
  digitalWrite(BUZZER_PIN, HIGH);
  digitalWrite(LED_PIN, LOW);
}

int nextAlarmIndex() {
  time_t nowE = time(nullptr);
  int best = -1;
  time_t bestAt = 0;
  for (int i = 0; i < alarmCount; i++) {
    if (!alarms[i].enabled) continue;
    time_t at = alarmEpoch(alarms[i]);
    if (at <= 0 || at < nowE) continue;
    if (best < 0 || at < bestAt) {
      best = i;
      bestAt = at;
    }
  }
  return best;
}

void drawScreen() {
  struct tm t;
  bool ok = getNow(t);
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  if (alarmActive) {
    display.setTextSize(2);
    display.setCursor(0, 0);
    display.println("MEDICINE");
    display.println("TIME");
    display.setTextSize(1);
    display.setCursor(0, 40);
    display.println(activeName);
    display.setCursor(0, 54);
    display.print(ok ? timeString(t) : "--:--:--");
  } else if (millis() < stopShownUntil) {
    display.setTextSize(2);
    display.setCursor(0, 0);
    display.println("TIMER");
    display.println("STOPPED");
    display.setTextSize(1);
    display.setCursor(0, 54);
    display.print(ok ? timeString(t) : "--:--:--");
  } else {
    display.setTextSize(2);
    display.setCursor(0, 4);
    display.print(ok ? timeString(t) : "Syncing");
    display.setTextSize(1);
    display.setCursor(0, 26);
    display.print(ok ? dateString(t) : "");
    display.setCursor(0, 38);
    int n = ok ? nextAlarmIndex() : -1;
    if (n >= 0) {
      display.print("Next ");
      display.print(String(alarms[n].day).substring(5));
      display.print(" ");
      display.print(alarms[n].hhmm);
    } else if (ok) {
      char day[12];
      strftime(day, sizeof(day), "%A", &t);
      display.print(day);
    }
    display.setCursor(0, 54);
    display.print(WiFi.localIP());
    display.print(":");
    display.print(port);
  }
  display.display();
}

void setup() {
  Serial.begin(115200);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(IR_PIN, INPUT);
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(LED_PIN, LOW);

  Wire.begin(21, 22);
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Connecting WiFi...");
  display.display();

  loadSettings();

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  unsigned long t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 20000) {
    delay(300);
  }

  applyTimezone();

  server = new WebServer(port);
  server->on("/", HTTP_GET, handleRoot);
  server->on("/api/alarms", HTTP_GET, handleGetAlarms);
  server->on("/api/alarms", HTTP_POST, handlePostAlarm);
  server->on(UriBraces("/api/alarms/{}"), HTTP_PUT, handlePutAlarm);
  server->on(UriBraces("/api/alarms/{}"), HTTP_DELETE, handleDeleteAlarm);
  server->on("/api/status", HTTP_GET, handleApiStatus);
  server->on("/setport", HTTP_GET, handleSetPort);
  server->on("/settz", HTTP_GET, handleSetTz);
  server->onNotFound(handleNotFound);
  server->begin();

  Serial.println(WiFi.localIP());
  Serial.println(port);

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("Open in browser:");
  display.println(WiFi.localIP());
  display.print("Port: ");
  display.println(port);
  display.display();
  delay(3000);
}

void loop() {
  server->handleClient();

  if (WiFi.status() != WL_CONNECTED && millis() - lastWifiTry > 30000) {
    lastWifiTry = millis();
    WiFi.reconnect();
  }

  struct tm t;
  bool ok = getNow(t);

  if (ok && !alarmActive) {
    time_t nowE = time(nullptr);
    for (int i = 0; i < alarmCount; i++) {
      if (!alarms[i].enabled) continue;
      time_t at = alarmEpoch(alarms[i]);
      if (at <= 0) continue;
      if (nowE >= at && nowE - at < LATE_WINDOW_SEC) {
        alarms[i].enabled = false;
        saveAlarms();
        startAlarm(alarms[i].name);
        break;
      }
    }
  }

  if (alarmActive) {
    if (motionDetected()) {
      stopAlarm();
    } else {
      unsigned long now = millis();
      if (now - lastBeep >= 300) {
        lastBeep = now;
        beepState = !beepState;
        digitalWrite(BUZZER_PIN, beepState ? HIGH : LOW);
      }
      if (now - alarmStart >= 500) digitalWrite(LED_PIN, HIGH);
    }
  }

  if (millis() - lastDraw >= 200) {
    lastDraw = millis();
    drawScreen();
  }
}
