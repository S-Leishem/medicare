#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

const char* WIFI_SSID = "Soubam";
const char* WIFI_PASS = "Linlin@1";
const int SERVER_PORT = 5500;

const int BUTTON_PIN = 27;
const int BUZZER_PIN = 26;
const int LED_PIN = 25;

Adafruit_SSD1306 display(128, 64, &Wire, -1);
WebServer server(SERVER_PORT);

bool alarmActive = false;
int stepIndex = 0;
unsigned long stepStart = 0;
unsigned long lastTrigger = 0;
unsigned long pressStart = 0;
bool pressing = false;

const uint16_t pattern[18] = {
  200, 200, 200, 200, 200, 600,
  600, 200, 600, 200, 600, 600,
  200, 200, 200, 200, 200, 1500
};

const char PAGE[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SOS Alert</title>
<style>
body{margin:0;font-family:Arial,sans-serif;text-align:center;color:#fff;background:#1b8a3a;min-height:100vh;display:flex;flex-direction:column;justify-content:center;align-items:center}
body.alert{background:#c40000;animation:blink 1s infinite}
@keyframes blink{50%{background:#7a0000}}
h1{font-size:2.2em;margin:0 0 10px}
p{font-size:1.2em;margin:0 0 30px}
button{font-size:1.6em;padding:18px 50px;border:none;border-radius:12px;background:#fff;color:#c40000;font-weight:bold;display:none}
body.alert button{display:block}
</style>
</head>
<body>
<h1 id="title">No Emergency</h1>
<p id="msg">System is ready</p>
<button onclick="stopAlarm()">STOP ALARM</button>
<script>
function update(){
  fetch('/status').then(r=>r.text()).then(t=>{
    var a=(t.trim()==='1');
    document.body.className=a?'alert':'';
    document.getElementById('title').innerText=a?'EMERGENCY ALERT!':'No Emergency';
    document.getElementById('msg').innerText=a?'SOS triggered. Help needed!':'System is ready';
  }).catch(()=>{});
}
function stopAlarm(){
  fetch('/stop').then(()=>update());
}
setInterval(update,1000);
update();
</script>
</body>
</html>
)rawliteral";

String ipString() {
  return WiFi.localIP().toString();
}

void showIdle() {
  display.clearDisplay();
  display.setTextSize(2);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("SOS READY");
  display.setTextSize(1);
  display.setCursor(0, 30);
  display.println("Link:");
  display.println("http://");
  display.print(ipString());
  display.print(":");
  display.println(SERVER_PORT);
  display.display();
}

void showAlarm() {
  display.clearDisplay();
  display.setTextSize(2);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("EMERGENCY!");
  display.setTextSize(1);
  display.setCursor(0, 24);
  display.println("Open on phone:");
  display.println("http://");
  display.print(ipString());
  display.print(":");
  display.println(SERVER_PORT);
  display.display();
}

void startAlarm() {
  alarmActive = true;
  stepIndex = 0;
  stepStart = millis();
  digitalWrite(BUZZER_PIN, HIGH);
  digitalWrite(LED_PIN, HIGH);
  showAlarm();
}

void stopAlarm() {
  alarmActive = false;
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(LED_PIN, LOW);
  lastTrigger = millis();
  showIdle();
}

void updateBuzzer() {
  if (!alarmActive) return;
  if (millis() - stepStart >= pattern[stepIndex]) {
    stepIndex = (stepIndex + 1) % 18;
    stepStart = millis();
    digitalWrite(BUZZER_PIN, stepIndex % 2 == 0 ? HIGH : LOW);
  }
}

bool buttonPressed() {
  bool down = digitalRead(BUTTON_PIN) == LOW;
  if (down && !pressing) {
    pressing = true;
    pressStart = millis();
  }
  if (!down) {
    pressing = false;
    return false;
  }
  if (pressing && millis() - pressStart >= 50) {
    return true;
  }
  return false;
}

void handleRoot() {
  server.send_P(200,